module.exports = {

"[project]/src/app/dashboard/configuration/modals/LeadResponseModal.jsx [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_dashboard_configuration_modals_LeadResponseModal_jsx_9e2ad5c6._.js.map