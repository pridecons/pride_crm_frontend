module.exports = {

"[project]/src/app/dashboard/configuration/modals/PermissionsModal.jsx [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_dashboard_configuration_modals_PermissionsModal_jsx_9a0a47c5._.js.map