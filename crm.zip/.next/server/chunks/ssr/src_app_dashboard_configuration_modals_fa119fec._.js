module.exports = {

"[project]/src/app/dashboard/configuration/modals/LeadResponseModal.jsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_app_dashboard_configuration_modals_LeadResponseModal_jsx_9e2ad5c6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/dashboard/configuration/modals/LeadResponseModal.jsx [app-ssr] (ecmascript)");
    });
});
}}),
"[project]/src/app/dashboard/configuration/modals/PermissionsModal.jsx [app-ssr] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_fbfd5722._.js",
  "server/chunks/ssr/[root-of-the-server]__84eb3961._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/dashboard/configuration/modals/PermissionsModal.jsx [app-ssr] (ecmascript)");
    });
});
}}),

};