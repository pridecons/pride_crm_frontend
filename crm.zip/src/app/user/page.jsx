"use client";

import UsersListPage from "@/components/User/UsersListPage";

export default function UserManagementPage() {
  return <UsersListPage />;
}
